library(testthat)
library(simple.RSS)

test_check("simple.RSS")
